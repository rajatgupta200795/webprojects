<div class="row">
	<div class="col-sm-1"></div>
	<div class="col-sm-1"><a href="home.php" class="btn btn-default"><span class="glyphicon glyphicon-home"></span> Home</a></div>
	<div class="col-sm-1"><a href="all_class.php" class="btn btn-default"><span class="glyphicon glyphicon-user"></span><span class="glyphicon glyphicon-user"></span> Class</a></div>
	<div class="col-sm-1"><a href="new_student.php"  class="btn btn-default"><span class="glyphicon glyphicon-plus"></span> New Student</a></div>
	<div class="col-sm-2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="messege_to_student.php" class="btn btn-default"><span class="glyphicon glyphicon-phone"></span> SMS</a></div>
	<div class="col-sm-2"></div>
</div>