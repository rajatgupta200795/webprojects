  </div>



</div>


</br></br>
<hr>
<p class="text-center">

<div style="padding-top:6%; padding-bottom:12%; background-color:black; text-align:center; color:white;">

	<samp>&copy; Copyright 2016 | www.mcskkt.com</br>
	All Rights Reserved<br>
	RGrouP Production    |    Contact Us +919807264017  |    Mail Us @ rajatgupta200795@gmail.com</samp>

</div>

</p>

</body>
</html>