<?php

$con = new mysqli('localhost','mcskktco_sonyssb','sonyssb.123','mcskktco_school') or die("could not connect to mysql".mysqli_error($con));


?>