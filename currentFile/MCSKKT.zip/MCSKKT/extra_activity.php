
<?php include"./inc/header.php";  


?>

<div class="container">

<center><h1>Extra Caricular activities</h1></center>
<hr style="height:3px;border:none;color:#333;background-color:#333;">
</br>
     
     <div class="row">	<div class="col-sm-1"></div>
     <div class="col-sm-3">
     	<h3>1. Weakly Quiz </h3></br>
     	<img class="img-circle" height="170" width="170" src="../img/quiz.jpg">
     
     	<hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>

     <div class="col-sm-3">
     	<h3>2. Mehndi Comptition</h3></br>
     	<img class="img-circle" width="170" height="170" src="../img/mehandi.jpg">

     	<hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>

     <div class="col-sm-3">           
     <h3>3. Cricket Comptition </h3></br>
     <img class="img-circle" width="170" height="170" width="150" src="../img/cricket.jpg">

     	<hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>
     </div>



          <div class="row">   <div class="col-sm-1"></div>
     <div class="col-sm-3">
          <h3>4. Boxing </h3></br>
          <img class="img-circle" width="170" height="170" width="170" src="../img/boxing.jpg">
     
          <hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>

     <div class="col-sm-3">
          <h3>5. Carom</h3></br>
          <img class="img-circle" width="170" height="170" src="../img/carom.jpg">

          <hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>

     <div class="col-sm-3">           
     <h3>6. Football </h3></br>
     <img class="img-circle" width="170" height="170" width="150" src="../img/football.jpg">

          <hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>
     </div>





          <div class="row">   <div class="col-sm-1"></div>
     <div class="col-sm-3">
          <h3>7. Dance</h3></br>
          <img class="img-circle" width="170" height="170" width="170" src="../img/dance.jpg">
     
          <hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>

     <div class="col-sm-3">
          <h3>8. Singing</h3></br>
          <img class="img-circle" width="170" height="170" src="../img/singing.jpg">

          <hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>

     <div class="col-sm-3">           
     <h3>9. Drama</h3></br>
     <img class="img-circle" width="170" height="170" width="150" src="../img/drama.jpg">

          <hr style="height:1px;border:none;color:#333;background-color:#333;">
     </div>
     </div>





     


</div>


<?php include"./inc/footer.php";  ?>
