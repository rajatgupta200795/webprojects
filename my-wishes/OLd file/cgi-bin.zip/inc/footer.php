</div>
</div>
</div>


</br></br></br>



<div style="bottom: 0px; padding-right:0px; position: relative; width: 100%; text-align: center; height: 75%; border-top: 1px solid #f3f3ee; background-color: #6c6767;">
    <div class="row">
        <div class="col-sm-3">
            <div style="font-family: 'Josefin Slab', serif; font-size: 35px; padding: 30px; color: white; font-weight: bold;"><a href="http://www.ewishes.online/"  style="color: white;"">ewishes.online</a></div>
        </div>
        <div class="col-sm-8" style="color: white; padding: 20px; font-size: 15px;font-family: 'PT Sans Caption', sans-serif;">
            <a href="http://www.ewishes.online/privacypolicy.php" style="color: white;">Privacy Policy</a> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="http://www.ewishes.online/about-us.php" style="color: white;">About Us</a> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="" style="color: white;">Contact Us</a> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="" style="color: white;">Help</a>
            </br></br>
            All Rights Reserved | Copyright 2017</br>
            Powered by RGroup</br>
            Developed by Rajat Gupta</br>

        </div>
    </div>
</div>


</body>
</html>