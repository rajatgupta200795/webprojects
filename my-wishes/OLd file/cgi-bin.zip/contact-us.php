<?php include "./inc/header.php";?>

<?php include "./inc/leftmenu.php";?>


<p style="font-size: 30px; font-family: 'Oswald', sans-serif, cursive; font-weight: bold;">Contact Us</p>

<hr style="width: 100%; text-align: center; height: 1px; border-top: 1px solid #f3f3ee; background-color: #f7f7f7;">
</br>

<p style="font-family: 'Josefin Slab', serif; font-size: 25px; font-weight: bold;">Website Owner ?</p>
<p style="font-family: 'PT Sans Caption', sans-serif; font-size: 18px;">
Thank you for your intrest in <a href="http://www.ewishes.online/">ewishes.online</a>. We are happy to find ourselves with you in your happy moment.
</br></br>
If you have any issues, suggestion or need of any kind of help, Please feel free to contact us.
</br></br>

<b>Email :</b> <a href="https://gmail.com">guptarajat20071995@gmail.com</a>

</br></br></br></br>

<p style="font-family: 'Josefin Slab', serif; font-size: 25px; font-weight: bold;">Website Developer</p>
<p style="font-family: 'PT Sans Caption', sans-serif; font-size: 18px;">
You can contact to our web developer via same Email
</br></br>

<b>Email :</b> <a href="https://gmail.com">guptarajat20071995@gmail.com</a> .</br></br>

Rajat Gupta is also intrested in any other web development activity. So if you want to hire him , Please feel free to mail . 
</br></br></br></br>

<b>Thank You</br>
ewishes.online Team
</b>
</p>
</p>


</div>
</div>
</div>

<?php include "./inc/footer.php";?>













