
<?php include"./inc/header.php";  


?>

<div class="container">

<center><h1>Uniform Details</h1></center>
<hr style="height:1px;border:none;color:#333;background-color:#333;">

</br></br>
Students have to come to school with uniform provided from school. Students have to wear two diffrent sets of uniform in diffrent days.</br></br></br>



<h2>1. Wednesday And Saturday</h2><hr>
<div class="row">
<div class="col-sm-1"></div>
<div class="col-sm-3">
<img width="70%" src="../img/uniform_1.jpg">
</div>
<div class="col-sm-4">
White Shirt And White Paint With Nevy Blue Tie And Belt.</br>
<b>Size :</b> Half or Full</br>
<b>Class :</b> All Class
</div>
</div>

</div>


<?php include"./inc/footer.php";  ?>
